@extends('layouts.master')
@section('title') Chat @endsection
@section('content')
@component('components.breadcrumb')                
    @slot('title') Chat @endslot
    @slot('li_1') Nazox @endslot
    @slot('li_2') Chat @endslot
@endcomponent 
<!-- Start row -->
<div class="d-lg-flex mb-4">
    <div class="chat-leftsidebar">
        <div class="p-3 border-bottom">
            <div class="media">
                <div class="align-self-center mr-3">
                    <img src="{{ URL::asset('/assets/images/users/avatar-2.jpg')}}" class="avatar-xs rounded-circle" alt="">
                </div>
                <div class="media-body">
                    <h5 class="font-size-15 mt-0 mb-1">Ricky Clark</h5>
                    <p class="text-muted mb-0"><i class="mdi mdi-circle text-success align-middle mr-1"></i> Active</p>
                </div>

                <div>
                    <div class="dropdown chat-noti-dropdown">
                        <button class="btn dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="mdi mdi-dots-horizontal font-size-20"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="#">Action</a>
                            <a class="dropdown-item" href="#">Another action</a>
                            <a class="dropdown-item" href="#">Something else here</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body border-bottom py-2">
            <div class="search-box chat-search-box">
                <div class="position-relative">
                    <input type="text" class="form-control" placeholder="Search...">
                    <i class="ri-search-line search-icon"></i>
                </div>
            </div>
        </div>

        <div class="chat-leftsidebar-nav">
            <ul class="nav nav-pills nav-justified">
                <li class="nav-item">
                    <a href="#chat" data-toggle="tab" aria-expanded="true" class="nav-link active">
                        <i class="ri-message-2-line font-size-20"></i>
                        <span class="mt-2 d-none d-sm-block">Chat</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#group" data-toggle="tab" aria-expanded="false" class="nav-link">
                        <i class="ri-group-line font-size-20"></i>
                        <span class="mt-2 d-none d-sm-block">Group</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#contact" data-toggle="tab" aria-expanded="false" class="nav-link">
                        <i class="ri-contacts-book-2-line font-size-20"></i>
                        <span class="mt-2 d-none d-sm-block">Contacts</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="tab-content py-4">
            <div class="tab-pane show active" id="chat">
                <div>
                    <h5 class="font-size-14 px-3 mb-3">Recent</h5>
                    <ul class="list-unstyled chat-list" data-simplebar style="max-height: 345px;">
                        <li class="active">
                            <a href="#">
                                <div class="media">
                                    
                                    <div class="user-img online align-self-center mr-3">
                                        <img src="{{ URL::asset('/assets/images/users/avatar-2.jpg')}}" class="rounded-circle avatar-xs" alt="">
                                        <span class="user-status"></span>
                                    </div>
                                    
                                    <div class="media-body overflow-hidden">
                                        <h5 class="text-truncate font-size-14 mb-1">Frank Vickery</h5>
                                        <p class="text-truncate mb-0">Hey! there I'm available</p>
                                    </div>
                                    <div class="font-size-11">04 min</div>
                                </div>
                            </a>
                        </li>

                        <li>
                            <a href="#">
                                <div class="media">
                                    <div class="user-img away align-self-center mr-3">
                                        <img src="{{ URL::asset('/assets/images/users/avatar-3.jpg')}}" class="rounded-circle avatar-xs" alt="">
                                        <span class="user-status"></span>
                                    </div>
                                    <div class="media-body overflow-hidden">
                                        <h5 class="text-truncate font-size-14 mb-1">Robert Winter</h5>
                                        <p class="text-truncate mb-0">I've finished it! See you so</p>
                                    </div>
                                    <div class="font-size-11">09 min</div>
                                </div>
                            </a>
                        </li>

                        <li>
                            <a href="#">
                                <div class="media">
                                    <div class="user-img online mr-3">
                                        <div class="avatar-xs align-self-center">
                                            <span class="avatar-title rounded-circle bg-light text-body">
                                                C
                                            </span>
                                        </div>
                                        <span class="user-status"></span>
                                    </div>
                                    <div class="media-body overflow-hidden">
                                        <h5 class="text-truncate font-size-14 mb-1">Crystal Elliott</h5>
                                        <p class="text-truncate mb-0">This theme is awesome!</p>
                                    </div>
                                    <div class="font-size-11">21 min</div>
                                </div>
                            </a>
                        </li>

                        <li>
                            <a href="#">
                                <div class="media">
                                    <div class="user-img align-self-center mr-3">
                                        <img src="{{ URL::asset('/assets/images/users/avatar-4.jpg')}}" class="rounded-circle avatar-xs" alt="">
                                        <span class="user-status"></span>
                                    </div>
                                    <div class="media-body overflow-hidden">
                                        <h5 class="text-truncate font-size-14 mb-1">Kristen Steele</h5>
                                        <p class="text-truncate mb-0">Nice to meet you</p>
                                    </div>
                                    <div class="font-size-11">1 hr</div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="media">
                                    <div class="user-img away mr-3">
                                        <div class="avatar-xs align-self-center">
                                            <span class="avatar-title rounded-circle bg-light text-body">
                                                M
                                            </span>
                                        </div>
                                        <span class="user-status"></span>
                                    </div>
                                    
                                    <div class="media-body overflow-hidden">
                                        <h5 class="text-truncate font-size-14 mb-1">Mitchel Givens</h5>
                                        <p class="text-truncate mb-0">Hey! there I'm available</p>
                                    </div>
                                    <div class="font-size-11">3 hrs</div>
                                </div>
                            </a>
                        </li>

                        <li>
                            <a href="#">
                                <div class="media">
                                    <div class="user-img online align-self-center mr-3">
                                        <img src="{{ URL::asset('/assets/images/users/avatar-6.jpg')}}" class="rounded-circle avatar-xs" alt="">
                                        <span class="user-status"></span>
                                    </div>
                                    <div class="media-body overflow-hidden">
                                        <h5 class="text-truncate font-size-14 mb-1">Stephen Hadley</h5>
                                        <p class="text-truncate mb-0">I've finished it! See you so</p>
                                    </div>
                                    <div class="font-size-11">5hrs</div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="media">
                                    <div class="user-img online mr-3">
                                        <div class="avatar-xs align-self-center">
                                            <span class="avatar-title rounded-circle bg-light text-body">
                                                K
                                            </span>
                                        </div>
                                        <span class="user-status"></span>
                                    </div>

                                    <div class="media-body overflow-hidden">
                                        <h5 class="text-truncate font-size-14 mb-1">Tracy Penley</h5>
                                        <p class="text-truncate mb-0">This theme is awesome!</p>
                                    </div>
                                    <div class="font-size-11">24/03</div>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="tab-pane" id="group">
                <h5 class="font-size-14 px-3 mb-3">Group</h5>
                <ul class="list-unstyled chat-list" data-simplebar style="max-height: 345px;">
                    <li>
                        <a href="#">
                            <div class="media align-items-center">
                                <div class="avatar-xs mr-3">
                                    <span class="avatar-title rounded-circle bg-light text-body">
                                        G
                                    </span>
                                </div>
                                
                                <div class="media-body">
                                    <h5 class="font-size-14 mb-0">General</h5>
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <div class="media align-items-center">
                                <div class="avatar-xs mr-3">
                                    <span class="avatar-title rounded-circle bg-light text-body">
                                        R
                                    </span>
                                </div>
                                
                                <div class="media-body">
                                    <h5 class="font-size-14 mb-0">Reporting</h5>
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <div class="media align-items-center">
                                <div class="avatar-xs mr-3">
                                    <span class="avatar-title rounded-circle bg-light text-body">
                                        M
                                    </span>
                                </div>
                                
                                <div class="media-body">
                                    <h5 class="font-size-14 mb-0">Meeting</h5>
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <div class="media align-items-center">
                                <div class="avatar-xs mr-3">
                                    <span class="avatar-title rounded-circle bg-light text-body">
                                        A
                                    </span>
                                </div>
                                
                                <div class="media-body">
                                    <h5 class="font-size-14 mb-0">Project A</h5>
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <div class="media align-items-center">
                                <div class="avatar-xs mr-3">
                                    <span class="avatar-title rounded-circle bg-light text-body">
                                        B
                                    </span>
                                </div>
                                
                                <div class="media-body">
                                    <h5 class="font-size-14 mb-0">Project B</h5>
                                </div>
                            </div>
                        </a>
                    </li>
                </ul>
            </div>

            <div class="tab-pane" id="contact">
                <h5 class="font-size-14 px-3 mb-3">Contact</h5>

                <div  data-simplebar style="max-height: 345px;">
                    <div>
                        <div class="p-3">
                            A
                        </div>

                        <ul class="list-unstyled chat-list">
                            <li>
                                <a href="#">
                                    <h5 class="font-size-14 mb-0">Adam Miller</h5>
                                </a>
                            </li>

                            <li>
                                <a href="#">
                                    <h5 class="font-size-14 mb-0">Alfonso Fisher</h5>
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div class="mt-4">
                        <div class="p-3">
                            B
                        </div>

                        <ul class="list-unstyled chat-list">
                            <li>
                                <a href="#">
                                    <h5 class="font-size-14 mb-0">Bonnie Harney</h5>
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div class="mt-4">
                        <div class="p-3">
                            C
                        </div>

                        <ul class="list-unstyled chat-list">
                            <li>
                                <a href="#">
                                    <h5 class="font-size-14 mb-0">Charles Brown</h5>
                                </a>
                                <a href="#">
                                    <h5 class="font-size-14 mb-0">Carmella Jones</h5>
                                </a>
                                <a href="#">
                                    <h5 class="font-size-14 mb-0">Carrie Williams</h5>
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div class="mt-4">
                        <div class="p-3">
                            D
                        </div>

                        <ul class="list-unstyled chat-list">
                            <li>
                                <a href="#">
                                    <h5 class="font-size-14 mb-0">Dolores Minter</h5>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="w-100 user-chat mt-4 mt-sm-0">
        <div class="p-3 px-lg-4 user-chat-border">
            <div class="row">
                <div class="col-md-4 col-6">
                    <h5 class="font-size-15 mb-1 text-truncate">Frank Vickery</h5>
                    <p class="text-muted text-truncate mb-0"><i class="mdi mdi-circle text-success align-middle mr-1"></i> Active now</p>
                </div>
                <div class="col-md-8 col-6">
                    <ul class="list-inline user-chat-nav text-right mb-0">
                        <li class="list-inline-item d-inline-block d-sm-none">
                            <div class="dropdown">
                                <button class="btn nav-btn dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="mdi mdi-magnify"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-md">
                                    <form class="p-2">
                                        <div class="search-box">
                                            <div class="position-relative">
                                                <input type="text" class="form-control rounded" placeholder="Search...">
                                                <i class="mdi mdi-magnify search-icon"></i>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </li>
                        <li class="d-none d-sm-inline-block">
                            <div class="search-box mr-2">
                                <div class="position-relative">
                                    <input type="text" class="form-control" placeholder="Search...">
                                    <i class="mdi mdi-magnify search-icon"></i>
                                </div>
                            </div>
                        </li>
                        <li class="list-inline-item m-0 d-none d-sm-inline-block">
                            <div class="dropdown">
                                <button class="btn nav-btn dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="mdi mdi-cog"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="#">View Profile</a>
                                    <a class="dropdown-item" href="#">Clear chat</a>
                                    <a class="dropdown-item" href="#">Muted</a>
                                    <a class="dropdown-item" href="#">Delete</a>
                                </div>
                            </div>
                        </li>

                        <li class="list-inline-item">
                            <div class="dropdown">
                                <button class="btn nav-btn dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="mdi mdi-dots-horizontal"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else</a>
                                </div>
                            </div>
                        </li>
                        
                    </ul>
                </div>
            </div>
        </div>

        <div class="px-lg-2">
            <div class="chat-conversation p-3">
                <ul class="list-unstyled mb-0 pr-3" data-simplebar style="max-height: 450px;">
                    <li>
                        <div class="conversation-list">
                            <div class="chat-avatar">
                                <img src="{{ URL::asset('/assets/images/users/avatar-2.jpg')}}" alt="">
                            </div>
                            <div class="ctext-wrap">
                                <div class="conversation-name">Frank Vickery</div>
                                <div class="ctext-wrap-content">
                                    <p class="mb-0">
                                        Hey! I am available
                                    </p>
                                </div>
                                <p class="chat-time mb-0"><i class="mdi mdi-clock-outline align-middle mr-1"></i> 12:09</p>
                            </div>
                            
                        </div>
                    </li>

                    <li class="right">
                        <div class="conversation-list">
                            <div class="ctext-wrap">
                                <div class="conversation-name">Ricky Clark</div>
                                <div class="ctext-wrap-content">
                                    <p class="mb-0">
                                        Hi, How are you? What about our next meeting?
                                    </p>
                                </div>

                                <p class="chat-time mb-0"><i class="bx bx-time-five align-middle mr-1"></i> 10:02</p>
                            </div>
                        </div>
                    </li>

                    <li> 
                        <div class="chat-day-title">
                            <span class="title">Today</span>
                        </div>
                    </li>
                    <li>
                        <div class="conversation-list">
                            <div class="chat-avatar">
                                <img src="{{ URL::asset('/assets/images/users/avatar-2.jpg')}}" alt="">
                            </div>
                            <div class="ctext-wrap">
                                <div class="conversation-name">Frank Vickery</div>
                                <div class="ctext-wrap-content">
                                    <p class="mb-0">
                                        Hello!
                                    </p>
                                </div>
                                <p class="chat-time mb-0"><i class="mdi mdi-clock-outline mr-1"></i> 10:00</p>
                            </div>
                            
                        </div>
                    </li>

                    <li class="right">
                        <div class="conversation-list">
                            <div class="ctext-wrap">
                                <div class="conversation-name">Ricky Clark</div>
                                <div class="ctext-wrap-content">
                                    <p class="mb-0">
                                        Hi, How are you? What about our next meeting?
                                    </p>
                                </div>

                                <p class="chat-time mb-0"><i class="mdi mdi-clock-outline mr-1"></i> 10:02</p>
                            </div>
                        </div>
                    </li>

                    <li>
                        <div class="conversation-list">
                            <div class="chat-avatar">
                                <img src="{{ URL::asset('/assets/images/users/avatar-2.jpg')}}" alt="">
                            </div>
                            <div class="ctext-wrap">
                                <div class="conversation-name">Frank Vickery</div>
                                <div class="ctext-wrap-content">
                                    <p class="mb-0">
                                        Yeah everything is fine
                                    </p>
                                </div>
                                
                                <p class="chat-time mb-0"><i class="mdi mdi-clock-outline mr-1"></i> 10:06</p>
                            </div>
                            
                        </div>
                    </li>

                    <li >
                        <div class="conversation-list">
                            <div class="chat-avatar">
                                <img src="{{ URL::asset('/assets/images/users/avatar-2.jpg')}}" alt="">
                            </div>
                            <div class="ctext-wrap">
                                <div class="conversation-name">Frank Vickery</div>
                                <div class="ctext-wrap-content">
                                    <p class="mb-0">& Next meeting tomorrow 10.00AM</p>
                                </div>
                                <p class="chat-time mb-0"><i class="mdi mdi-clock-outline mr-1"></i> 10:06</p>
                            </div>
                            
                        </div>
                    </li>

                    <li class="right">
                        <div class="conversation-list">
                            <div class="ctext-wrap">
                                <div class="conversation-name">Ricky Clark</div>
                                <div class="ctext-wrap-content">
                                    <p class="mb-0">
                                        Wow that's great
                                    </p>
                                </div>

                                <p class="chat-time mb-0"><i class="mdi mdi-clock-outline mr-1"></i> 10:07</p>
                            </div>
                        </div>
                    </li>
                    
                    
                </ul>
            </div>
            
        </div>
        <div class="px-lg-3">
            <div class="p-3 chat-input-section">
                <div class="row">
                    <div class="col">
                        <div class="position-relative">
                            <input type="text" class="form-control chat-input" placeholder="Enter Message...">
                            
                        </div>
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-primary chat-send w-md waves-effect waves-light"><span class="d-none d-sm-inline-block mr-2">Send</span> <i class="mdi mdi-send"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end row -->
@endsection
                    