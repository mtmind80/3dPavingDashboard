@extends('layouts.master')
@section('title') FAQs @endsection
@section('body')
<body data-sidebar="dark">
@endsection
@section('content')
@component('components.breadcrumb')
    @slot('title') FAQs @endslot
    @slot('li_1') Utility @endslot
    @slot('li_2') FAQs @endslot
@endcomponent 
<div class="row">
<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
            <div class="row mt-4">
                <div class="col-lg-12">
                    <div class="text-center">
                        <h4>Have any Questions ?</h4>
                        <p class="text-muted">It will be as simple as in fact, it will be occidental. it will seem like simplified English, as a skeptical Cambridge friend</p>

                        <div>
                            <button type="button" class="btn btn-primary mt-2 mr-2 waves-effect waves-light">Email Us</button>
                            <button type="button" class="btn btn-info mt-2 waves-effect waves-light">Send us a tweet</button>
                        </div>
                    </div>

                    
                </div>
            </div>

            <div class="row mt-5 justify-content-center">
                <div class="col-lg-10">
                    <div>
                        <ul class="nav nav-pills faq-nav-tabs justify-content-center" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="pill" href="#faq-gen-ques" role="tab">
                                    General Questions
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="pill" href="#faq-privacy" role="tab">
                                    Privacy Policy
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" data-toggle="pill" href="#faq-pricing" role="tab">
                                    Pricing & Plans
                                </a>
                            </li>
                        </ul>

                        <div class="tab-content pt-5">
                            <div class="tab-pane fade show active" id="faq-gen-ques" role="tabpanel">
                                <div>
                                    <div class="text-center mb-5">
                                        <h5>General Questions</h5>
                                        <p>Sed ut perspiciatis unde omnis iste natus error sit</p>
                                    </div>

                                    <div id="gen-question-accordion" class="custom-accordion-arrow">
                                        <div class="card">
                                            <a href="#gen-question-collapseOne" class="text-dark" data-toggle="collapse"
                                                            aria-expanded="true"
                                                            aria-controls="gen-question-collapseOne">
                                                <div class="card-header" id="gen-question-headingOne">
                                                    <h5 class="font-size-14 m-0">
                                                        <i class="mdi mdi-chevron-up accor-arrow-icon"></i> What is Lorem Ipsum ?
                                                        
                                                    </h5>
                                                </div>
                                            </a>
    
                                            <div id="gen-question-collapseOne" class="collapse show"
                                                    aria-labelledby="gen-question-headingOne" data-parent="#gen-question-accordion">
                                                <div class="card-body">
                                                    If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages. The new common language will be more simple and regular than the existing
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <a href="#gen-question-collapseTwo" class="collapsed" data-toggle="collapse"
                                                            aria-expanded="false"
                                                            aria-controls="gen-question-collapseTwo">
                                                <div class="card-header" id="gen-question-headingTwo">
                                                    <h5 class="font-size-14 m-0">
                                                        <i class="mdi mdi-chevron-up accor-arrow-icon"></i> Why do we use it ?
                                                    </h5>
                                                </div>
                                            </a>
                                            <div id="gen-question-collapseTwo" class="collapse" aria-labelledby="gen-question-headingTwo"
                                                    data-parent="#gen-question-accordion">
                                                <div class="card-body">
                                                    Everyone realizes why a new common language would be desirable one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words.
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <a href="#gen-question-collapseThree" class="collapsed" data-toggle="collapse"
                                                            aria-expanded="false"
                                                            aria-controls="gen-question-collapseThree">
                                                <div class="card-header" id="gen-question-headingThree">
                                                    <h5 class="font-size-14 m-0">
                                                        <i class="mdi mdi-chevron-up accor-arrow-icon"></i> Where can I get some ?
                                                    </h5>
                                                </div>
                                            </a>
                                            <div id="gen-question-collapseThree" class="collapse"
                                                    aria-labelledby="gen-question-headingThree" data-parent="#gen-question-accordion">
                                                <div class="card-body">
                                                    Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <a href="#gen-question-collapseFour" class="collapsed" data-toggle="collapse"
                                                            aria-expanded="false"
                                                            aria-controls="gen-question-collapseFour">
                                                <div class="card-header" id="gen-question-headingFour">
                                                    <h5 class="font-size-14 m-0">
                                                        <i class="mdi mdi-chevron-up accor-arrow-icon"></i> Where does it come from ?
                                                    </h5>
                                                </div>
                                            </a>
                                            <div id="gen-question-collapseFour" class="collapse"
                                                    aria-labelledby="gen-question-headingFour" data-parent="#gen-question-accordion">
                                                <div class="card-body">
                                                    To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is. The European languages are members of the same family separate existence.
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <a href="#gen-question-collapseFive" class="collapsed" data-toggle="collapse"
                                                            aria-expanded="false"
                                                            aria-controls="gen-question-collapseFive">
                                                <div class="card-header" id="gen-question-headingFive">
                                                    <h5 class="font-size-14 m-0">
                                                        <i class="mdi mdi-chevron-up accor-arrow-icon"></i> Where can I get some ?
                                                    </h5>
                                                </div>
                                            </a>
                                            <div id="gen-question-collapseFive" class="collapse"
                                                    aria-labelledby="gen-question-headingFive" data-parent="#gen-question-accordion">
                                                <div class="card-body">
                                                    It will be as simple in fact, it will be occidental. To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what occidental languages are members
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="faq-privacy" role="tabpanel">
                                <div>
                                    <div class="text-center mb-5">
                                        <h5>Privacy Policy</h5>
                                        <p>Neque porro quisquam est, qui dolorem ipsum quia</p>
                                    </div>

                                    <div id="privacy-accordion" class="custom-accordion-arrow">
                                            
                                        <div class="card">
                                            <a href="#privacy-collapseOne" class="collapsed" data-toggle="collapse"
                                                            aria-expanded="false"
                                                            aria-controls="privacy-collapseOne">
                                                <div class="card-header" id="privacy-headingOne">
                                                    <h5 class="font-size-14 m-0">
                                                        <i class="mdi mdi-chevron-up accor-arrow-icon"></i> Why do we use it ?
                                                    </h5>
                                                </div>
                                            </a>
                                            <div id="privacy-collapseOne" class="collapse" aria-labelledby="privacy-headingOne"
                                                    data-parent="#privacy-accordion">
                                                <div class="card-body">
                                                    Everyone realizes why a new common language would be desirable one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words.
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <a href="#privacy-collapseTwo" class="text-dark" data-toggle="collapse"
                                                            aria-expanded="true"
                                                            aria-controls="privacy-collapseTwo">
                                                <div class="card-header" id="privacy-headingTwo">
                                                    <h5 class="font-size-14 m-0">
                                                        <i class="mdi mdi-chevron-up accor-arrow-icon"></i> What is Lorem Ipsum ?
                                                    </h5>
                                                </div>
                                            </a>
    
                                            <div id="privacy-collapseTwo" class="collapse show"
                                                    aria-labelledby="privacy-headingOne" data-parent="#privacy-accordion">
                                                <div class="card-body">
                                                    If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages. The new common language will be more simple and regular than the existing
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <a href="#privacy-collapseThree" class="collapsed" data-toggle="collapse"
                                                            aria-expanded="false"
                                                            aria-controls="privacy-collapseThree">
                                                <div class="card-header" id="privacy-headingThree">
                                                    <h5 class="font-size-14 m-0">
                                                        <i class="mdi mdi-chevron-up accor-arrow-icon"></i> Where can I get some ?
                                                    </h5>
                                                </div>
                                            </a>
                                            <div id="privacy-collapseThree" class="collapse"
                                                    aria-labelledby="privacy-headingThree" data-parent="#privacy-accordion">
                                                <div class="card-body">
                                                    Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <a href="#privacy-collapseFour" class="collapsed" data-toggle="collapse"
                                                            aria-expanded="false"
                                                            aria-controls="privacy-collapseFour">
                                                <div class="card-header" id="privacy-headingFour">
                                                    <h5 class="font-size-14 m-0">
                                                        <i class="mdi mdi-chevron-up accor-arrow-icon"></i> Where does it come from ?
                                                    </h5>
                                                </div>
                                            </a>
                                            <div id="privacy-collapseFour" class="collapse"
                                                    aria-labelledby="privacy-headingFour" data-parent="#privacy-accordion">
                                                <div class="card-body">
                                                    To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is. The European languages are members of the same family separate existence.
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <a href="#privacy-collapseFive" class="collapsed" data-toggle="collapse"
                                                            aria-expanded="false"
                                                            aria-controls="privacy-collapseFive">
                                                <div class="card-header" id="privacy-headingFive">
                                                    <h5 class="font-size-14 m-0">
                                                        <i class="mdi mdi-chevron-up accor-arrow-icon"></i> Where can I get some ?
                                                    </h5>
                                                </div>
                                            </a>
                                            <div id="privacy-collapseFive" class="collapse"
                                                    aria-labelledby="privacy-headingFive" data-parent="#privacy-accordion">
                                                <div class="card-body">
                                                    It will be as simple in fact, it will be occidental. To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what occidental languages are members
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="faq-pricing" role="tabpanel">
                                <div>
                                    <div class="text-center mb-5">
                                        <h5>Pricing & Plans</h5>
                                        <p>Sed ut perspiciatis unde omnis iste natus error sit</p>
                                    </div>

                                    <div id="pricing-accordion" class="custom-accordion-arrow">
                                            
                                        <div class="card">
                                            <a href="#pricing-collapseOne" class="text-dark" data-toggle="collapse"
                                                            aria-expanded="true"
                                                            aria-controls="pricing-collapseOne">
                                                <div class="card-header" id="pricing-headingOne">
                                                    <h5 class="font-size-14 m-0">
                                                        <i class="mdi mdi-chevron-up accor-arrow-icon"></i> What is Lorem Ipsum ?
                                                    </h5>
                                                </div>
                                            </a>
    
                                            <div id="pricing-collapseOne" class="collapse show"
                                                    aria-labelledby="pricing-headingOne" data-parent="#pricing-accordion">
                                                <div class="card-body">
                                                    If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages. The new common language will be more simple and regular than the existing
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <a href="#pricing-collapseTwo" class="collapsed" data-toggle="collapse"
                                                            aria-expanded="false"
                                                            aria-controls="pricing-collapseTwo">
                                                <div class="card-header" id="pricing-headingTwo">
                                                    <h5 class="font-size-14 m-0">
                                                        <i class="mdi mdi-chevron-up accor-arrow-icon"></i> Where can I get some ?
                                                    </h5>
                                                </div>
                                            </a>
                                            <div id="pricing-collapseTwo" class="collapse"
                                                    aria-labelledby="pricing-headingTwo" data-parent="#pricing-accordion">
                                                <div class="card-body">
                                                    It will be as simple in fact, it will be occidental. To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what occidental languages are members
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <a href="#pricing-collapseThree" class="collapsed" data-toggle="collapse"
                                                            aria-expanded="false"
                                                            aria-controls="pricing-collapseThree">
                                                <div class="card-header" id="pricing-headingThree">
                                                    <h5 class="font-size-14 m-0">
                                                        <i class="mdi mdi-chevron-up accor-arrow-icon"></i> Why do we use it ?
                                                    </h5>
                                                </div>
                                            </a>
                                            <div id="pricing-collapseThree" class="collapse" aria-labelledby="pricing-headingThree"
                                                    data-parent="#pricing-accordion">
                                                <div class="card-body">
                                                    Everyone realizes why a new common language would be desirable one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words.
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <a href="#pricing-collapseFour" class="collapsed" data-toggle="collapse"
                                                            aria-expanded="false"
                                                            aria-controls="pricing-collapseFour">
                                                <div class="card-header" id="pricing-headingFour">
                                                    <h5 class="font-size-14 m-0">
                                                        <i class="mdi mdi-chevron-up accor-arrow-icon"></i> Where can I get some ?
                                                    </h5>
                                                </div>
                                            </a>
                                            <div id="pricing-collapseFour" class="collapse"
                                                    aria-labelledby="pricing-headingFour" data-parent="#pricing-accordion">
                                                <div class="card-body">
                                                    Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <a href="#pricing-collapseFive" class="collapsed" data-toggle="collapse"
                                                            aria-expanded="false"
                                                            aria-controls="pricing-collapseFive">
                                                <div class="card-header" id="pricing-headingFive">
                                                    <h5 class="font-size-14 m-0">
                                                        <i class="mdi mdi-chevron-up accor-arrow-icon"></i> Where does it come from ?
                                                    </h5>
                                                </div>
                                            </a>
                                            <div id="pricing-collapseFive" class="collapse"
                                                    aria-labelledby="pricing-headingFive" data-parent="#pricing-accordion">
                                                <div class="card-body">
                                                    To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is. The European languages are members of the same family separate existence.
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
@endsection
